# RCSCodingFeatures
here is code that we have written during our learning
This code is released for all to see

izveidot izmaiņas (rediģēt failus)
izveidojam commitu (ar komentāru) no izmaiņām
aizsūtam commitu uz GitHub